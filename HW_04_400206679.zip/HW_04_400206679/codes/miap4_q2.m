close all;
clear all;
clc;
% f1= imread('melanoma_gray.jpg');
% f2= imread('nevus_gray.jpg');
% [u1,v1]= GVF(f1,0.01,50);
% T1= sqrt(u1.*u1+ v1.*v1);
% figure;
% subplot(1,2,2);
% imshow(T1);title('melanoma-GVF');
% 
% [u2,v2]= GVF(f2,0.01,50);
% T2= sqrt(u2.*u2+ v2.*v2);
% subplot(1,2,1);
% imshow(T2);title('nevus-GVF');

g1= imread('MRI1.png');
[u3,v3]= GVF(g1,0.01,50);
T3= sqrt(u3.*u3+ v3.*v3);
figure;
imshow(T3);
title('MRI1-GVF');