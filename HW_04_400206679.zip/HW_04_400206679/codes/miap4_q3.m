close all;
clear all;
clc;

%% segmentation of 'melanoma' image
%  image1=imread('melanoma_gray.jpg');
% 
% %user_inputed_mask
% mask1=roipoly(image1);
% 
% bw1=activecontour(image1,mask1);
% 
% imshow(bw1)

%creation of 9*9 square mask and center defined by user
% figure()
% imshow(image1)
% [center_x,center_y] = ginput (1);
% 
% mask_x= uint8(center_x-4:center_x+4);
% mask_y= uint8(center_y-4:center_y+4);
% 
% [rows,cals]=size(image1);
% mask=zeros(rows,cals);
% mask(mask_x,mask_y)=1;
% imshow(mask)
% bw11=activecontour(image1,mask);
% imshow(bw11)
% title('9*9 mask by user defined center');



%% segmentation of 'nevus' image
% image2=imread('nevus_gray.jpg');
% % 
% % %user_inputed_mask
% % mask2=roipoly(image2);
% % 
% % bw2=activecontour(image2,mask2);
% % 
% % imshow(bw2)
%creation of 9*9 square mask and center defined by user
% % figure()
% % imshow(image2)
% % [center_x,center_y] = ginput (1);
% % 
% % mask_x= uint8(center_x-4:center_x+4);
% % mask_y= uint8(center_y-4:center_y+4);
% % 
% % [rows,cals]=size(image2);
% % mask=zeros(rows,cals);
% % mask(mask_x,mask_y)=1;
% % imshow(mask)
% % bw22=activecontour(image2,mask);
% % imshow(bw22)
% % title('9*9 mask by user defined center');



%% segmentation of 'nevus' image
image3=imread('MRI3.png');
% 
% %user_inputed_mask
% mask3=roipoly(image3);
% 
% bw3=activecontour(image3,mask3);
% 
% imshow(bw3)
%creation of 9*9 square mask and center defined by user
figure()
imshow(image3)
[center_x,center_y] = ginput (1);

mask_x= uint8(center_x-4:center_x+4);
mask_y= uint8(center_y-4:center_y+4);

[rows,cals]=size(image3);
mask=zeros(rows,cals);
mask(mask_x,mask_y)=1;
imshow(mask)
bw33=activecontour(image3,mask);
imshow(bw33)
title('9*9 mask by user defined center');





