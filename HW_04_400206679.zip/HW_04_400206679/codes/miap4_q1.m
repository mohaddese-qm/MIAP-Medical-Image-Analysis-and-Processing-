clc
close all
clear variables

% load the images
img1 = im2double(imread('MRI1.png'));
img2 = im2double(imread('MRI2.png'));
img3 = im2double(imread('MRI3.png'));
img4 = im2double(imread('MRI4.png'));

% % % % choose 3 of the images as rgb channels of a new image
% % % rgb1 = cat(3, img1, img2, img3);
% % % rgb2 = cat(3, img2, img3, img4);
% % % rgb3 = cat(3, img1, img3, img4);
% % % rgb4 = cat(3, img1, img2, img4);
% % % rgb5 = cat(3, img4, img2, img3);
% % % rgb6 = cat(3, img3, img2, img4);
% % % figure;
% % % subplot(2,3,1);imshow(rgb1); title('img1-img2-img3')
% % % 
% % % subplot(2,3,2);imshow(rgb2); title('img2-img3-img4')
% % % 
% % % subplot(2,3,3);imshow(rgb3); title('img1-img3-img4')
% % % 
% % % subplot(2,3,4);imshow(rgb4); title('img1-img2-img4')
% % % 
% % % subplot(2,3,5);imshow(rgb5); title('img4-img2-img3')
% % % 
% % % subplot(2,3,6);imshow(rgb6); title('img3-img2-img4')
% % % 
% % % figure;
% % % subplot(2,2,1), imhist(img1), title('Histogram of MRI1');
% % % subplot(2,2,2), imhist(img2), title('Histogram of MRI2');
% % % subplot(2,2,3), imhist(img3), title('Histogram of MRI3');
% % % subplot(2,2,4), imhist(img4), title('Histogram of MRI4');
% % % 


optimal_k = true;  % set to 'true' if you want to use the optimal k from kmeans
part_5 = false;

% reshape images to vectors
img1_vec = reshape(img1, [], 1);
img2_vec = reshape(img2, [], 1);
img3_vec = reshape(img3, [], 1);
img4_vec = reshape(img4, [], 1);

% kmeans to find optimal number of clusters 
eva = evalclusters(img1_vec, 'kmeans', 'DaviesBouldin',...
    'kList', (3:8));
figure;
plot(eva)
% % % 
% % % % k : number of clusters 
% % % % q : fuzziness parameter
% % % if optimal_k == true
% % %     k = eva.OptimalK;
% % % else
% % %     k = 5;
% % % end
% % % Qs = [2, 5 ,1.1];
% % % 
% % % images = [img1_vec, img2_vec, img3_vec, img4_vec];
% % % 
% % % % fcm 
% % % 
% % % for q = Qs
% % %     for img = 1 : 4
% % %         [centers, U] = fcm(images(:, img), k, [q, NaN, NaN, NaN]);
% % %         if part_5 == true
% % %             [M, I] = max(U, [], 1);
% % %             hard_U = zeros(size(U));
% % %             for n = 1 : size(U,2)
% % %                 hard_U(I(n), n) = 1;
% % %             end
% % %         end
% % %         figure
% % %         for i = 1 : k
% % %             if part_5 == true
% % %                 map = reshape(hard_U(i,:), size(img1, 1), size(img1, 2));
% % %             else
% % %                 map = reshape(U(i,:), size(img1, 1), size(img1, 2));
% % %             end
% % %             subplot(1, k, i)
% % %             imshow(squeeze(map))
% % %             title(strcat('MRI', num2str(img), ' q = ', num2str(q), ...
% % %                 ' cluster = ', num2str(i)))
% % %         end
% % %     end
% % % end
% % % 
% % % % kmeans (q=1)
% % % 
% % % for img = 1 : 4
% % %     idx = kmeans(images(:, img), k);
% % %     maps = zeros(k, size(img1, 1), size(img1, 2));
% % %     figure
% % %     imshow(reshape(idx, size(img1, 1), size(img1, 2)), [])
% % %     title(strcat('MRI', num2str(img), ' q=1'))
% % %     figure
% % %     for i = 1 : k 
% % %         cluster = find(idx == i);
% % %         maps(i, cluster) = 255;
% % %         subplot(1, k, i)
% % %         imshow(squeeze(maps(i, :, :)))
% % %         title(strcat('MRI', num2str(img), ' q =1', ' cluster = ', num2str(i)))
% % %     end
% % % end
% % % 
