clc;close all;clear all;

%% snake:
I=im2double(imread('example.png'));
  x=[96 51 98 202 272 280 182];
  y=[63 147 242 262 211 97 59];
  P=[x(:) y(:)];
  Options=struct;
Options=struct;
Options.Verbose=true;
Options.Iterations=1000;
Options.Delta = 0.02;
Options.Alpha = 0.5;
Options.Beta = 0.2;
figure(1);
[O,J]=Snake2D(I,P,Options);
Irgb(:,:,1)=I;
  Irgb(:,:,2)=I;
  Irgb(:,:,3)=J;
  figure, imshow(Irgb,[]); 
  hold on; plot([O(:,2);O(1,2)],[O(:,1);O(1,1)]);