clc;close all;clear all;


Y=im2double(imread('test_biasfield_noise.png'));
 % Class prototypes (means)
   v = [0.42;0.56;0.64];
 % Do the fuzzy clustering
   [B,U]=BCFCM2D(Y,v,struct('maxit',5,'epsilon',1e-5));
 % Show results
   figure, 
   subplot(2,2,1), imshow(Y), title('input image');
   subplot(2,2,2), imshow(U), title('Partition matrix');
   subplot(2,2,3), imshow(B,[]), title('Estimated biasfield');
   subplot(2,2,4), imshow(Y-B), title('Corrected image');
