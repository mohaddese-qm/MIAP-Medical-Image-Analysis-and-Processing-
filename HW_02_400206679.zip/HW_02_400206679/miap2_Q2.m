clc;close all;clear all;
img1=imread('brain.jpg');
imshow(img1)
title 'brain-img'
% IHE1=histeq(img1);
% imhist(IHE1)
% title('Histogram of Equalized brainImage');
% average_brain_img=mean(mean(IHE1))
% V1=double(IHE1)
% variance_brain_img=var(var(V1))
% entropy_brain_img= entropy(IHE1)
% standarddeviation_brain_img = std2 (img1)


% % 
% clc;close all;clear all;
% img2=imread('sample.png');
% imshow(img2)
% title 'sample-img'
% IHE2=histeq(img2);
% 
% imhist(IHE2)
% title('Histogram of Equalized sampleImage');
% average_sample_img=mean(mean(IHE2))
% V2=double(IHE2)
% variance_sample_img=var(var(V2))
% entropy_sample_img= entropy(IHE2)
% standarddeviation_sample_img = std2 (img2)




 glcm = graycomatrix(img1,'Offset',[0 1])





