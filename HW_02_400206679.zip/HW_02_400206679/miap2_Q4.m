% clc;close all;clear all;
% img=imread('covid.png');
% colormap gray
% img1=rgb2gray(img)
% [LoD, HiD] = wfilters ( 'haar' , 'd' );
% [cA, cH, cV, cD] = dwt2 (img1, LoD, HiD, 'mode' , 'symh' );
% thr = 0.1;
% cAthard= wthresh (cA, 'h' , thr);
% cHthard= wthresh (cH, 'h' , thr);
% cVthard= wthresh (cV, 'h' , thr);
% cDthard= wthresh (cD, 'h' , thr);
% figure(1)
% subplot (2,2,1)
% imagesc (cA)
% colormap gray 
% title ( 'Approximation' )
% subplot (2,2,2)
% imagesc (cHthard)
% colormap gray 
% title ( 'Horizontal-hard-thr0.1' )
% subplot (2,2,3)
% imagesc (cVthard)
% colormap gray 
% title ( 'Vertical-hard-thr0.1' )
% subplot (2,2,4)
% imagesc (cDthard)
% colormap gray 
% title ( 'Diagonal-hard-thr0.1' )


% clc;close all;clear all;
% img=imread('covid.png');
% colormap gray
% img1=rgb2gray(img)
% [LoD, HiD] = wfilters ( 'haar' , 'd' );
% [cA, cH, cV, cD] = dwt2 (img1, LoD, HiD, 'mode' , 'symh' );
% thr = 60;
% cAthard= wthresh (cA, 's' , thr);
% cHthard= wthresh (cH, 's' , thr);
% cVthard= wthresh (cV, 's' , thr);
% cDthard= wthresh (cD, 's' , thr);
% figure(2)
% subplot (2,2,1)
% imagesc (cA)
% colormap gray 
% title ( 'Approximation' )
% subplot (2,2,2)
% imagesc (cHthard)
% colormap gray 
% title ( 'Horizontal-soft-thr60' )
% subplot (2,2,3)
% imagesc (cVthard)
% colormap gray 
% title ( 'Vertical-soft-thr60' )
% subplot (2,2,4)
% imagesc (cDthard)
% colormap gray 
% title ( 'Diagonal-soft-thr60' )

clc;close all;clear all;
img=imread('covid.png');
colormap gray
img1=rgb2gray(img)
[LoD, HiD] = wfilters ( 'haar' , 'd' );
[cA, cH, cV, cD] = dwt2 (img1, LoD, HiD, 'mode' , 'symh' );
% thr = 60;
% cAthard= wthresh (cA, 's' , thr);
% cHthard= wthresh (cH, 's' , thr);
% cVthard= wthresh (cV, 's' , thr);
% cDthard= wthresh (cD, 's' , thr);
% figure(2)
% subplot (2,2,1)
% imagesc (cA)
% colormap gray 
% title ( 'Approximation' )
% subplot (2,2,2)
% imagesc (cHthard)
% colormap gray 
% title ( 'Horizontal-soft-thr60' )
% subplot (2,2,3)
% imagesc (cVthard)
% colormap gray 
% title ( 'Vertical-soft-thr60' )
% subplot (2,2,4)
% imagesc (cDthard)
% colormap gray 
% title ( 'Diagonal-soft-thr60' )

xrecD = idwt2([],[],[],cD,'haar')
xrecH = idwt2([],cH,[],[],'haar');
xrecV = idwt2([],[],cV,[],'haar')
xrecA = idwt2(cA,[],[],[],'haar')


subplot(221)
imagesc(xrecA)
title('Approximation-idwt2')

subplot(222)
imagesc(xrecH)
title('Horizontal-idwt2')

subplot(223)
imagesc(xrecV)
title('Vertical-idwt2')

subplot(224)
imagesc(xrecD)
title('Diagonal-idwt2')



