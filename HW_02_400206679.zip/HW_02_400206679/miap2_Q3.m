

clc;close all;clear all;
img1=imread('boat.png');
kernelLP =1/(4*sqrt(2))*[1+sqrt(3), 3+sqrt(3),3-sqrt(3),1-sqrt(3)];
kernelHP =1/(4*sqrt(2))*[1-sqrt(3), -3+sqrt(3),3+sqrt(3),-1-sqrt(3)];
img2= imfilter(img1, kernelLP);
img3 = imfilter(img1, kernelHP);


%%lowpassmask_________________________________
% [LoD, HiD] = wfilters ( 'db2' , 'd' );
% [cA, cH, cV, cD] = dwt2 (img2, LoD, HiD, 'mode' , 'symh' );
% subplot (2,2,1)
% imagesc (cA)
% colormap gray 
% title ( 'Approximation-LowPassmask' )
% subplot (2,2,2)
% imagesc (cH)
% colormap gray 
% title ( 'Horizontal-LPmask' )
% subplot (2,2,3)
% imagesc (cV)
% colormap gray 
% title ( 'Vertical-LPmask' )
% subplot (2,2,4)
% imagesc (cD)
% colormap gray 
% title ( 'Diagonal-LPmask' )

%%highpassmask________________________________________
[LoD, HiD] = wfilters ( 'db2' , 'd' );
[cA, cH, cV, cD] = dwt2 (img3, LoD, HiD, 'mode' , 'symh' );
subplot (2,2,1)
imagesc (cA)
colormap gray 
title ( 'Approximation-HighPassmask' )
subplot (2,2,2)
imagesc (cH)
colormap gray 
title ( 'Horizontal-HPmask' )
subplot (2,2,3)
imagesc (cV)
colormap gray 
title ( 'Vertical-HPmask' )
subplot (2,2,4)
imagesc (cD)
colormap gray 
title ( 'Diagonal-HPmask' )

inversekernelLP =1/(4*sqrt(2))*[3-sqrt(3), 3+sqrt(3),1+sqrt(3),1-sqrt(3)];
inversekernelHP =1/(4*sqrt(2))*[1-sqrt(3), -1-sqrt(3),3+sqrt(3),-3+sqrt(3)];
img4= imfilter(img1,inversekernelLP);
img5= imfilter(img1,inversekernelHP);


%% inverse_lowpassmask_________________________________
% [LoD, HiD] = wfilters ( 'db2' , 'd' );
% [cA, cH, cV, cD] = dwt2 (img4, LoD, HiD, 'mode' , 'symh' );
% subplot (2,2,1)
% imagesc (cA)
% colormap gray 
% title ( 'Approximation-inverse-LPmask' )
% subplot (2,2,2)
% imagesc (cH)
% colormap gray 
% title ( 'Horizontal-inv-LPmask' )
% subplot (2,2,3)
% imagesc (cV)
% colormap gray 
% title ( 'Vertical-inv-LPmask' )
% subplot (2,2,4)
% imagesc (cD)
% colormap gray 
% title ( 'Diagonal-inv-LPmask' )


%% inverse_highpassmask_________________________________
% [LoD, HiD] = wfilters ( 'db2' , 'd' );
% [cA, cH, cV, cD] = dwt2 (img5, LoD, HiD, 'mode' , 'symh' );
% subplot (2,2,1)
% imagesc (cA)
% colormap gray 
% title ( 'Approximation-inverse-HPmask' )
% subplot (2,2,2)
% imagesc (cH)
% colormap gray 
% title ( 'Horizontal-inv-HPmask' )
% subplot (2,2,3)
% imagesc (cV)
% colormap gray 
% title ( 'Vertical-inv-HPmask' )
% subplot (2,2,4)
% imagesc (cD)
% colormap gray 
% title ( 'Diagonal-inv-HPmask' )
% 

