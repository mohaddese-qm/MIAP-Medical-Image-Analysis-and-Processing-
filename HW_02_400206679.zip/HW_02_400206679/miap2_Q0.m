clc;close all;clear all;
img=imread('melanome4.jpg');
img1=im2bw(img,0.25);
img2=imcomplement(img1);
img3=imopen(img2,strel('disk',15));
imshow(img3);
title 'A^c opening with B'

% 
% clc;close all;clear all;
% img=imread('melanome4.jpg');
% img1=im2bw(img,0.25);
% 
% closed = imclose(img1, strel('disk', 15));
% img2=imcomplement(closed);
% imshow(img2);
% title '(A closing with B )^c'
