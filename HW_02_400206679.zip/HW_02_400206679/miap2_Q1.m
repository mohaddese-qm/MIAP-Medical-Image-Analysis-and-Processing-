%p0:
% clc;close all;clear all;
% img=imread('melanome2.jpg');
% 
% img1=im2bw(img,0.25);
% img2=imcomplement(img1);
% imshow(img2);
% title 'binarymelanome2'
%____________________________________
%p1:
% clc;close all;clear all;
% img=imread('melanome1.jpg');
% img1=im2bw(img,0.25);
% img2=imcomplement(img1);
% SE=ones(5);
% img3=imdilate(img2,SE)
% imshow(img3);
% title 'delationmelanome1'

%_____________________________________
%p2_1
% clc;close all;clear all;
% img=imread('melanome2.jpg');
% img1=im2bw(img,0.25);
% img2=imcomplement(img1);
% SE=ones(2);
% img3=imerode(img2,SE)
% imshow(img3);
% title 'erosionmelanome2'
%____________________________
%p2_2
% clc;close all;clear all;
% img=imread('melanome2.jpg');
% img1=im2bw(img,0.25);
% img2=imcomplement(img1);
% SE=ones(3);
% img3=imerode(img2,SE)
% k2= img2-img3;
% % Display inner boundary im imfill(BW4,'holes');age.
% imshow(k2);
% title 'boundary extraction melanome2'
%_________________________________________
%p3
% clc;close all;clear all;
% img=imread('melanome3.jpg');
% img1=im2bw(img,0.25);
% img2=imcomplement(img1);
% closed = imclose(img2, strel('disk', 13));
% filled = imfill(closed, 'holes');
% imshow(filled);
% title 'filledmelanome3'
% %________________________________________
% %p4
% clc;close all;clear all;
% img=imread('melanome4.jpg');
% img1=im2bw(img,0.25);
% img2=imcomplement(img1);
% img3=imopen(img2,strel('disk',15));
% imshow(img3);
% title 'separatemelanome4'
%______________________________________
% %p5
clc;close all;clear all;
img=imread('melanome3.jpg');
img1=im2bw(img,0.25);
img2=imcomplement(img1);
closed = imclose(img2, strel('disk', 13));
filled = imfill(closed, 'holes');
CC = bwconncomp(filled)
labeled = labelmatrix(CC)
RGB_label = label2rgb(labeled,@copper,'c','shuffle');
imshow(RGB_label)
title 'connected component of filled melanome3'
% 
% CC = bwconncomp(img2)
% labeled = labelmatrix(CC)
% RGB_label = label2rgb(labeled,@copper,'c','shuffle');
% imshow(RGB_label)
% title 'connected component of melanome3'



















