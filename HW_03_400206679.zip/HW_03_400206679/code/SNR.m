%% Calculate SNR for Noisy image  
function SNR = SNR(noisy , clearimg)
    temp1 =0;
    temp2 =0;
    S=size(noisy);
    for i=1:S(1)
        for j=1:S(2)
            temp1 = temp1 + noisy(i,j)^2;
            temp2 = temp2 + (noisy(i,j)-clearimg(i,j))^2;
        end
    end
    SNR=10*log(temp1/temp2);
    
end
