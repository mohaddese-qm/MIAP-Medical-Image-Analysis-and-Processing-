clc;close all;clear all;
img1 = phantom ( 'Modified Shepp-Logan' , 700);
J= imnoise(img1,'salt & pepper',0.03);
imshow(J);title ('saLt & pepper Noisy phantom img1');
lambda = 1;niter = 100;
denoised_img = TVL1denoise(J, lambda, niter);
figure(2);imshow(denoised_img);title('denoised phantom image');


snr = SNR(J,denoised_img)
epi = EPI(J,denoised_img)
