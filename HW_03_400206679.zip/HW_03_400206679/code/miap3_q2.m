clc;close all;clear all;
img1 = phantom ( 'Modified Shepp-Logan' , 700);
J= imnoise(img1,'salt & pepper',0.03);
imshow(J);
title ('saLt & pepper Noisy phantom img1');
  niter = 5;
  lambda=0.25;
  kappa = 30;
  option = 2;

diff = anisodiff(img1, niter, kappa, lambda, option);
% 
figure;
imshow(diff)
title ('denoise image with anisodiff');

%diff=imread("phantom.png")

epi = EPI(J,diff)
SNR = SNR(J,diff)