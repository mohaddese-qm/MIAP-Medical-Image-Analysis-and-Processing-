clc;close all;clear all;
% Origin_img = imread('hand.jpg');
% img1=rgb2gray(Origin_img)
% Noisy_img = imnoise(Origin_img,'gaussian',0.05,0.01);
%montage ({img1,Noisy_img })

% figure()
% imshow(Noisy_img),title('Noisy-img');

%%
% B=imgaussfilt(Noisy_img,1.5,"FilterDomain","spatial","FilterSize",11);
% figure()
% imshow(B), title('Denoised Image with gaussian kernel');
% 
% epi = EPI(Noisy_img,B)
% SNR = SNR(Noisy_img,B)


%%
im=imread('hand.jpg');
out=bilateralGrayscale(im,3,0.2,0.1);
imshow(out),title('Denoised Image with bilateral kernel');

snr = SNR(Noisy_img,Denoised_img)
epi = EPI(Noisy_img,Denoised_img)

%%
% fima=NLmeansfilter(double(Noisy_img),3,1,0.2);
% imagesc(fima)
% colormap gray;title('NLM-denoised-image');
% 
% snr = SNR(Noisy_img,fima)
% epi = EPI(Noisy_img,fima)









