close all;
clc;
a=imread('river1.png');
b=imread('river2.png');
g=imread('river3.png');
d=imread('river4.png');
e=imread('river5.png');
f=imread('river6.png');
ad=im2double(a);
x=ad;
[r,c]=size(ad);
factor=6;
for i=1:r
    for j=1:c
        x(i,j)=factor*log(1+ad(i,j));
    end
end
subplot(231);imshow(x);
 title('river1');

ad=im2double(b);
y=ad;
[r,c]=size(ad);
factor=6;
for i=1:r
    for j=1:c
        y(i,j)=factor*log(1+ad(i,j));
    end
end
subplot(232);imshow(y);
title('river2');

ad=im2double(g);
z=ad;
[r,c]=size(ad);
factor=6;
for i=1:r
    for j=1:c
        z(i,j)=factor*log(1+ad(i,j));
    end
end
subplot(233);imshow(z);
title('river3');


ad=im2double(d);
n=ad;
[r,c]=size(ad);
factor=6;
for i=1:r
    for j=1:c
        n(i,j)=factor*log(1+ad(i,j));
    end
end
subplot(234);imshow(n);
title('river4');


ad=im2double(e);
m=ad;
[r,c]=size(ad);
factor=6;
for i=1:r
    for j=1:c
        m(i,j)=factor*log(1+ad(i,j));
    end
end
subplot(235);imshow(m);
title('river5');

ad=im2double(f);
o=ad;
[r,c]=size(ad);
factor=6;
for i=1:r
    for j=1:c
        o(i,j)=factor*log(1+ad(i,j));
    end
end
subplot(236);imshow(o);
title('river6');

% title('river3');
% title('river4');
% title('river5');
% title('river6');
% 

