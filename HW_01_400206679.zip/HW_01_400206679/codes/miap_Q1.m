%part1
I=imread('histogram.jpeg');
IHE=histeq(I);
histequ=imshow(IHE);
figure
subplot(2,1,1), imhist(I), title('Histogram of Original Image');
subplot(2,1,2), imhist(IHE), title('Histogram of Equalized Image');

%% part2

x=imread('histequ.jpg');
% x=imread('histogram.jpeg');
[M,N]=size(x);
t=1:256;
n=0:255;
count=0;
for z=1:256
    for i=1:M
        for j=1:N
            
            if x(i,j)==z-1
                count=count+1;
            end
        end
    end
            t(z)=count;
            count=0;
end
% disp(t')
histgram=stem(n,t); 
grid on;
ylabel('no. of pixels with intensity levels---->');
xlabel('intensity levels---->'); title('HISTOGRAM OF THE IMAGE-histogram equalization ');

% ylabel('no. of pixels with intensity levels---->');
% xlabel('intensity levels---->'); title('HISTOGRAM OF THE IMAGE ');

%%part3

x=imread('histogram.jpeg');
x=rgb2gray(x);
x=im2double(x);
[m,n]=size(x);
gamma=2;
c=1
for i=1:m
    for j=1:n
        cx(i,j)=c*(x(i,j)^gamma);
    end
end
imshow(x); title('increased contrast');


IHE=histeq(x);
histequ=imshow(IHE);
figure
subplot(2,1,1), imhist(x), title('Histogram of Original Image');
subplot(2,1,2), imhist(IHE), title('Histogram of Equalized Image');





