clc
clear ali;
imgRGB = imread('brainMRI.png');
[r, c, ~] = size(imgRGB);
c = round(c/2);
r = round(r/2);
for i = 2:3
    
 imgRGB([1:r],[c:731],i) = imgRGB([1:r],[c:731],1);

  img1=imgRGB([1:r],[c:731],i);
  
end
%figure(1);imshow(img1)
for i = 2:3
    
  imgRGB([1:r],[1:c],i) = imnoise(imgRGB([1:r],[1:c],1),'salt & pepper');

  img2=imgRGB([1:r],[1:c],i);
  
end
%figure(2);imshow(img2)
 for i = 2:3

  imgRGB([r:781],[1:c],i) = imnoise(imgRGB([r:781],[1:c],1),'gaussian');
  img3=imgRGB([r:781],[1:c],i);
  
end
%figure(3);imshow(img3);
 for i = 2:3
 N1 = imnoise(imgRGB,'gaussian');
  N2=imnoise(N1,'salt & pepper');
  imgRGB([r:781],[c:731],i) = imnoise(N2([r:781],[c:731],1),'gaussian');
 
  img4=imgRGB([r:781],[c:731],i);
 end
%figure(4);imshow(img4)

% 
  brainMRInoise=[img2 img1;img3 img4];
  imshow(brainMRInoise) 
%  
% %  h=ones(3,3)/9;
% %  h=ones(5,5)/25;
%  h=ones(7,7)/49;
%  avg=imfilter(brainMRInoise,h);
%  figure
%  imshow(avg)
%  title('filtered image')

%  
%  K1 = medfilt2(brainMRInoise,[7,7]);
% figure(1);imshow(K1);title('size7');
% K2 = medfilt2(brainMRInoise,[4,4]);
% figure(2);imshow(K2);title('size4');
% k3 = medfilt2(brainMRInoise,[3,3]);
% figure(3);imshow(k3);title('size3');
% 

%  hgauss= fspecial ('gaussian' ,[5 5],1) ;
%  Agauss=imfilter (brainMRInoise,hgauss) ;
%  
 
%  B = imgaussfilt(brainMRInoise,3)
%  imshow(B); title ( 'gaussian 3' ) ;

c=wiener2(brainMRInoise,[6,6]);
imshow(c);title ( 'wiener6 filter' ) ;

K1 = medfilt2(brainMRInoise,[7,7]);
figure(1);imshow(K1);title('size7');

 B = imgaussfilt(K1,2)
 imshow(B); title ( ' median 7 and gaussian 2 ' ) ;



 