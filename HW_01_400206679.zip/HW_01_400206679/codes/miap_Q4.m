%%part1,2:
clear all; close all; clc
% imdata = imread('hand.jpg');
% figure(1);imshow(imdata); title('Original Image of hand');
% imdata = rgb2gray(imdata);
% figure(2); imshow(imdata); title('Gray Image');
% %Get Fourier Transform of an image
% F = fft2(imdata);
% % Fourier transform of an image
% S = abs(F);
% figure(3);imshow(S,[]);title('Fourier transform of an image');
% %get the centered spectrum
% Fsh = fftshift(F);
% figure(4);imshow(abs(Fsh),[]);title('Centered fourier transform of Image(hand)')
% %apply log transform
% S2 = log(1+abs(Fsh));
% figure(5);imshow(S2,[]);title('log transformed Image')

% 
% imdata = imread('foot.jpg');
% figure(1);imshow(imdata); title('Original Image of foot');
% imdata = rgb2gray(imdata);
% figure(2); imshow(imdata); title('Gray Image');
% %Get Fourier Transform of an image
% F = fft2(imdata);
% % Fourier transform of an image
% S = abs(F);
% figure(3);imshow(S,[]);title('Fourier transform of an image');
% %get the centered spectrum
% Fsh = fftshift(F);
% figure(4);imshow(abs(Fsh),[]);title('Centered fourier transform of Image(foot)')
% %apply log transform
% S2 = log(1+abs(Fsh));
% figure(5);imshow(S2,[]);title('log transformed Image')


%%part3:
i1 = imread('hand.jpg');
i1 = rgb2gray(i1);

F1 = fft2(i1);
mag_hand = abs(F1);
pha_hand = angle(F1);



i2 = imread('foot.jpg');
i2 = rgb2gray(i2);
F2 = fft2(i2);
mag_foot = abs(F2);
pha_foot = angle(F2);



out1 = mag_hand .* exp(j*pha_foot);
out2 = mag_foot .* exp(j*pha_hand);

% Find the inverse images
out1 = real(ifft2(out1));
out2 = real(ifft2(out2));

% Show the images
figure();
subplot(221);imshow(i1); title('Original Image of hand');
subplot(222);imshow(i2); title('Original Image of foot');
subplot(223);imshow(out1, []);title('Image Reconstruction from Magnitude of Image-hand and Phase of Image-foot');
subplot(224);imshow(out2, []);title('Image Reconstruction from Magnitude of Image-foot and Phase of Image-hand');

