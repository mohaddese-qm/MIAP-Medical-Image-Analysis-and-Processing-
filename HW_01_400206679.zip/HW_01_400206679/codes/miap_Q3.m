% [1,?1], [1,0], transpose[1,0,?1],[1,-2,1],transpose[1,-2,1],
%canny,sobel,Laplacian filter


clc;
close all;
clear all;

Im = imread('wall.jpeg');
Im2 = rgb2gray(Im);
% CannyM = edge(Im2,'canny');
% figure, imshow(CannyM);
% title('Canny method');

% sobelM = edge(Im2,'sobel');
% figure, imshow(sobelM);
% title('sobel method');

% g=[0 1 0;1 -4 1;0 1 0];
% output=imfilter(Im2,g);
% figure();imshow(output);title('Laplacian method');


f=[0 0 0;0 1 0;0 0 0]+2.*[0 1 0;1 -4 1;0 1 0];
output=imfilter(Im2,f);
figure();imshow(output);title('edit of Laplacian method');






% kernel = [1, -1];
% outputImage = imfilter(Im2, kernel);
% figure, imshow(outputImage);
% title('[1, -1]');


% kernel = [1, 0];
% outputImage = imfilter(Im2, kernel);
% figure, imshow(outputImage);
% title('[1, 0]');
% 
% 
% kernel = [1,-2,1];
% outputImage = imfilter(Im2, kernel);
% figure, imshow(outputImage);
% title('[1,-2,1]');


% kernel = [1;0;-1];
% outputImage = imfilter(Im2, kernel);
% figure, imshow(outputImage);
% title('transpose[1,0,-1]');

% 
% kernel = [1;-2;1];
% outputImage = imfilter(Im2, kernel);
% figure, imshow(outputImage);
% title('transpose[1,-2,1]');
% 





